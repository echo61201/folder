const express = require('express');
const bodyParser = require('body-parser');
const exphbs = require('express-handlebars');
const fs = require('fs'); // Import the fs module
const path = require('path'); // Import the path module

const moviesFilePath = path.join(__dirname, 'movies.json');

const app = express();

// Function to read movies from the JSON file
function readMoviesFromFile() {
    const data = fs.readFileSync(moviesFilePath);
    return JSON.parse(data); // Parse the JSON data
}




// Configure Handlebars to use .hbs extension
app.engine('hbs', exphbs.engine({
    extname: '.hbs', // Specify the file extension
    defaultLayout: 'mainLayOut',
    layoutsDir: path.join(__dirname, 'views', 'layouts'),
    partialsDir: path.join(__dirname, 'views', 'partials'),
    helpers: {
        uppercase: (str) => str.toUpperCase()
    }
}));

// Set the view engine to 'hbs'
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));

// Serve static files
// Middleware to parse incoming request body
app.use(express.urlencoded({ extended: true })); // This parses form data
app.use(express.json()); // This parses JSON data if needed
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.get('/', (req, res) => {
    const data = {
        title: 'Home Page',
        msg: 'Welcome to the home page!'
    };
    res.render('index', data);
});

/*
app.get('/movies',(req,res) => {
    const data ={
        title:'movie list',
        msg:'movies are listed below',
        movies:[
            {id:'1',title:'movie1',director:'A'},
            {id:'2',title:'movie2',director:'B'},
            {id:'3',title:'movie3',director:'C'},
            {id:'4',title:'movie4',director:'D'}
        ]
    }
    res.render('movies',data)
})
    */

app.get('/movies', (req, res) => {
    const movies = readMoviesFromFile(); // Read the movies from the JSON file
    const data = {
        title: 'Movie List',
        msg: 'Movies are listed below',
        movies: movies
    };
    res.render('movies', data);
});


app.get('/movies/:id', (req, res) => {
    const movies = readMoviesFromFile(); // Read current movies
    const movieId = req.params.id; // Get the movie ID from the request parameters
    const movie = movies.find(m => m.id === movieId);

    if (movie) {
        res.render('movie_details', movie); // Pass the movie object directly
    } else {
        res.status(404).send('Movie not found');
    }
});

app.get('/movie/new', (req, res) => {
    res.render('new_movie', { layout: 'mainLayOut' });
});

app.post('/movies', (req, res) => {
    const movies = readMoviesFromFile(); // Read current movies
    const newMovie = {
        id: (movies.length + 1).toString(), // Generate a new ID
        title: req.body.title,
        director: req.body.director,
        year: req.body.year,
        desc: req.body.desc
    };

    movies.push(newMovie); // Add the new movie to the array

    fs.writeFileSync(moviesFilePath, JSON.stringify(movies, null, 2)); // Write back to the JSON file

    res.redirect('/movies'); // Redirect to the movies list page
});


// 404 Handler
app.use((req, res) => {
    res.status(404).render('404', { 
        title: '404 - Not Found'
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
